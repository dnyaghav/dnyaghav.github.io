chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({
    url: "https://dnyaghav.github.io/tools/ext/unfollower"
  });
});
