// Start/Stop toggle
const toggleBtn = document.getElementById("toggleBtn");
let isRunning = false;

toggleBtn.addEventListener("click", async () => {
  isRunning = !isRunning;
  const interval = parseInt(document.getElementById("intervalInput").value) * 1000;
  const limit = parseInt(document.getElementById("limitInput").value);
  const breakDuration = parseInt(document.getElementById("breakInput").value) * 1000;

  if (isRunning) {
    toggleBtn.textContent = "⏹ Stop";
    toggleBtn.classList.remove("btn-success");
    toggleBtn.classList.add("btn-danger");

    // Inject unfollow script with params
    chrome.scripting.executeScript({
      target: { tabId: (await getCurrentTab()).id },
      func: unfollowScript,
      args: [interval, limit, breakDuration]
    });
  } else {
    toggleBtn.textContent = "▶ Start";
    toggleBtn.classList.remove("btn-danger");
    toggleBtn.classList.add("btn-success");

    alert("Unfollower stopped ✅");
  }
});

// Helper: Get active tab
async function getCurrentTab() {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Script that runs inside Instagram
function unfollowScript(interval, limit, breakDuration) {
  (async function () {
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const findButtonByText = (text) =>
      Array.from(document.querySelectorAll("button"))
        .find((btn) => btn.innerText === text);

    let unfollowCount = 0;

    while (true) {
      for (let i = 0; i < limit; i++) {
        const followButton = findButtonByText("Following");
        if (!followButton) {
          console.log("No more users to unfollow or button not found.");
          return;
        }
        followButton.click();
        await delay(200);

        const confirmButton = findButtonByText("Unfollow");
        if (confirmButton) {
          confirmButton.click();
          unfollowCount++;
          console.log(`Unfollowed #${unfollowCount}`);
        }

        await delay(interval);
      }
      console.log(`Taking a break for ${breakDuration / 1000} seconds...`);
      await delay(breakDuration);
    }
  })();
}

// Rotating taglines
const taglines = [
  "“Fuel the code, support the creator!”",
  "“Your support keeps this project alive 🚀”",
  "“One coffee = One more feature ☕”",
  "“Big or small, every donation counts ❤️”",
  "“Code more, worry less – thanks to you 🙌”"
];
let taglineIndex = 0;
setInterval(() => {
  taglineIndex = (taglineIndex + 1) % taglines.length;
  document.getElementById("donationTagline").innerText = taglines[taglineIndex];
}, 4000);
