// Placeholder for future content features (like overlay notices)
console.log("Bulk Unfollower content script is active.");
