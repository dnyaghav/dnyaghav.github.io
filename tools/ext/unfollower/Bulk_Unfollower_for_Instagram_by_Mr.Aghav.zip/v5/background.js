chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({
    url: "https://dnyaghav.github.io/ext/Bulk_Unfollower_for_Instagram_by_Mr.Aghav.html"
  });
});
